// src/appointments/appointments.service.ts
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateAppointmentDto } from './dto/create-appointment.dto';
import { UpdateAppointmentDto } from './dto/update-appointment.dto';

@Injectable()
export class AppointmentsService {
  constructor(private prisma: PrismaService) { }

  async create(data: CreateAppointmentDto) {
    console.log('Criando appointment:', data);
    return this.prisma.appointment.create({ data });
  }

  async findAll() {
    return this.prisma.appointment.findMany({
      include: { user: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findOne(id: string) {
    return this.prisma.appointment.findUnique({ where: { id } });
  }

  // src/appointments/appointments.service.ts
  async findByUser(userId: string) {
    return this.prisma.appointment.findMany({
      where: { userId },
      include: { user: true }, // garante que o frontend receba o user
      orderBy: { createdAt: 'desc' },
    });
  }

  async update(id: string, data: UpdateAppointmentDto) {
    return this.prisma.appointment.update({
      where: { id },
      data,
    });
  }
}
