// src/appointments/dto/update-appointment.dto.ts
export class UpdateAppointmentDto {
    status?: 'PENDING' | 'CONFIRMED' | 'CANCELLED' | 'RESCHEDULED' | 'COMPLETED';
    date?: string; // ISO string da nova data/hora
}
