import { Injectable, BadRequestException, UnauthorizedException } from '@nestjs/common';
import { PrismaService } from './prisma.service';
import * as bcrypt from 'bcrypt';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';

@Injectable()
export class AuthService {
  constructor(private prisma: PrismaService) { }

  async register(dto: RegisterDto) {
    const { name, cpf, password, confirmPassword } = dto;

    const existing = await this.prisma.user.findUnique({ where: { cpf } });
    if (existing) {
      throw new BadRequestException('CPF already registered');
    }

    /* if (password !== confirmPassword) {
      throw new BadRequestException('Passwords do not match');
    } */

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await this.prisma.user.create({
      data: {
        name,
        cpf,
        password: hashedPassword,
      },
    });

    return { message: 'User created successfully', user: { id: user.id, name: user.name, cpf: user.cpf } };
  }

  async login(dto: LoginDto) {
    const { cpf, password } = dto;

    const user = await this.prisma.user.findUnique({ where: { cpf } });

    if (!user || !user.password) throw new UnauthorizedException('Invalid CPF or password');

    const isValid = await bcrypt.compare(password, user.password);
    if (!isValid) throw new UnauthorizedException('Invalid CPF or password');

    return { message: 'Login successful', user: { id: user.id, name: user.name, cpf: user.cpf } };
  }

  async getUserNameById(id: string) {
    const user = await this.prisma.user.findUnique({
      where: { id },
      select: { name: true },
    });
    return user;
  }

}
