import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { ConfigService } from '@nestjs/config'; // Importa o ConfigService
import { AuthService } from './auth.service';
import { PrismaService } from './prisma.service';
import { JwtStrategy } from './jwt.strategy';
import { AuthController } from './auth.controller';

@Module({
  imports: [
    PassportModule,
    JwtModule.registerAsync({
      imports: [],
      inject: [ConfigService], // Injeta o ConfigService
      useFactory: async (configService: ConfigService) => ({
        secret: configService.get('JWT_SECRET', 'default_secret'), // Acessa a variável de ambiente JWT_SECRET
        signOptions: { expiresIn: '1d' },
      }),
    }),
  ],
  controllers: [AuthController],
  providers: [AuthService, PrismaService, JwtStrategy],
})
export class AuthModule {}
