import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { PrismaService } from './auth/prisma.service';
import cookieParser from 'cookie-parser';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.use(cookieParser());

  const prismaService = app.get(PrismaService);
  await prismaService.enableShutdownHooks(app);

  app.enableCors({
  origin: (origin, callback) => {
    const allowedOrigins = [
      'https://checkagora.vercel.app',
      'http://localhost:3001',
    ];

    // Permite requests sem origin (como Postman ou SSR)
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true, // importante para cookies
});



  await app.listen(3000);
}
bootstrap();
