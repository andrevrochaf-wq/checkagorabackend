import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config'; // Importa o ConfigModule
import { AuthModule } from './auth/auth.module';
import { AppointmentsModule } from './appointments/appointments.module';
import { PrismaModule } from './prisma/prisma.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true, // Faz com que as variáveis de ambiente sejam acessíveis globalmente
    }),
    AuthModule, AppointmentsModule, PrismaModule,
  ],
})
export class AppModule {}
