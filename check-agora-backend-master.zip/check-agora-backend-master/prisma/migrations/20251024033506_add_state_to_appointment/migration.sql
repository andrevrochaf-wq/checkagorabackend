/*
  Warnings:

  - Added the required column `city` to the `Appointment` table without a default value. This is not possible if the table is not empty.
  - Added the required column `state` to the `Appointment` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Appointment" ADD COLUMN     "city" TEXT NOT NULL,
ADD COLUMN     "district" TEXT,
ADD COLUMN     "examType" TEXT,
ADD COLUMN     "hospital" TEXT,
ADD COLUMN     "state" TEXT NOT NULL;
